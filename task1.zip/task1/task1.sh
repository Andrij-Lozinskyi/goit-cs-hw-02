#!/bin/bash

LOG_FILE="website_status.log"
echo "Starting website check" > "$LOG_FILE"

websites=(
    "https://google.com"
    "https://facebook.com"
    "https://x.com"
    "https://fklvmdlkfv.com"
)

check_website() {
    local url=$1
    local http_code
    
    http_code=$(curl -o /dev/null -s -w "%{http_code}" --max-time 10 "$url")
    
    if [ $? -eq 0 ] && [ "$http_code" -ge 200 ] && [ "$http_code" -lt 400 ]; then
        echo "[$url] is UP (HTTP Code: $http_code)"
        echo "[$url] is UP (HTTP Code: $http_code)" >> "$LOG_FILE"
    else
        echo "[$url] is DOWN (HTTP Code: $http_code)"
        echo "[$url] is DOWN (HTTP Code: $http_code)" >> "$LOG_FILE"
    fi
}

for site in "${websites[@]}"; do
    check_website "$site"
done